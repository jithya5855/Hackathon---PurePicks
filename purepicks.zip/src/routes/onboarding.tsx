import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppNav } from "@/components/AppNav";
import {
  emptyProfile,
  loadProfile,
  saveProfile,
  type Profile,
} from "@/lib/profile-store";

export const Route = createFileRoute("/onboarding")({
  head: () => ({
    meta: [
      { title: "Setup your profile · PurePicks" },
      {
        name: "description",
        content:
          "Tell PurePicks your allergies and select your skin and hair type for personalized product scans.",
      },
    ],
  }),
  component: Onboarding,
});

type Step = 0 | 1 | 2 | 3;

const SKIN_OPTIONS = ["Normal", "Oily", "Dry", "Combination", "Sensitive"];
const HAIR_OPTIONS = ["Straight", "Wavy", "Curly", "Coily"];

function Onboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>(0);
  const [profile, setProfile] = useState<Profile>(() => emptyProfile());
  const [allergyDraft, setAllergyDraft] = useState("");

  useEffect(() => {
    const existing = loadProfile();
    if (existing) setProfile(existing);
  }, []);

  const addAllergy = () => {
    const v = allergyDraft.trim();
    if (!v) return;
    if (profile.allergies.includes(v)) return;
    setProfile((p) => ({ ...p, allergies: [...p.allergies, v].slice(0, 30) }));
    setAllergyDraft("");
  };
  const removeAllergy = (a: string) =>
    setProfile((p) => ({ ...p, allergies: p.allergies.filter((x) => x !== a) }));

  const onFinish = () => {
    saveProfile(profile);
    navigate({ to: "/scan" });
  };

  return (
    <div className="min-h-screen">
      <AppNav />
      <main className="mx-auto max-w-3xl px-6 py-12">
        <Stepper step={step} />

        {step === 0 && (
          <Panel
            title="What are you allergic or sensitive to?"
            subtitle="Add anything — ingredients, foods, fragrances. Skip if none."
          >
            <div className="flex gap-2">
              <input
                value={allergyDraft}
                onChange={(e) => setAllergyDraft(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    addAllergy();
                  }
                }}
                placeholder="e.g. peanuts, fragrance, sulfates"
                className="flex-1 rounded-xl border border-input bg-secondary/40 px-4 py-3 outline-none placeholder:text-muted-foreground focus:border-primary"
              />
              <button
                onClick={addAllergy}
                className="rounded-xl bg-primary px-5 font-medium text-primary-foreground transition hover:opacity-90"
              >
                Add
              </button>
            </div>
            {profile.allergies.length > 0 && (
              <div className="mt-5 flex flex-wrap gap-2">
                {profile.allergies.map((a) => (
                  <button
                    key={a}
                    onClick={() => removeAllergy(a)}
                    className="chip group hover:border-destructive"
                  >
                    {a}
                    <span className="text-muted-foreground group-hover:text-destructive">
                      ×
                    </span>
                  </button>
                ))}
              </div>
            )}
            <Footer
              onBack={null}
              onNext={() => setStep(1)}
              nextLabel="Continue"
            />
          </Panel>
        )}

        {step === 1 && (
          <TypePicker
            title="What is your skin type?"
            subtitle="Pick the option that best describes your skin most of the time."
            options={SKIN_OPTIONS}
            currentValue={profile.skinType}
            onSelect={(v) => setProfile((p) => ({ ...p, skinType: v }))}
            onBack={() => setStep(0)}
            onNext={() => setStep(2)}
          />
        )}

        {step === 2 && (
          <TypePicker
            title="What is your hair type?"
            subtitle="Pick the option that best describes your natural hair texture."
            options={HAIR_OPTIONS}
            currentValue={profile.hairType}
            onSelect={(v) => setProfile((p) => ({ ...p, hairType: v }))}
            onBack={() => setStep(1)}
            onNext={() => setStep(3)}
          />
        )}

        {step === 3 && (
          <Panel
            title="Your profile is ready"
            subtitle="PurePicks will use this every time you scan."
          >
            <dl className="space-y-4 text-sm">
              <Row label="Allergies">
                {profile.allergies.length ? (
                  <div className="flex flex-wrap gap-2">
                    {profile.allergies.map((a) => (
                      <span key={a} className="chip">
                        {a}
                      </span>
                    ))}
                  </div>
                ) : (
                  <span className="text-muted-foreground">None</span>
                )}
              </Row>
              <Row label="Skin">
                <div className="font-medium">
                  {profile.skinType ?? "Not selected"}
                </div>
              </Row>
              <Row label="Hair">
                <div className="font-medium">
                  {profile.hairType ?? "Not selected"}
                </div>
              </Row>
            </dl>
            <Footer
              onBack={() => setStep(2)}
              onNext={onFinish}
              nextLabel="Save & start scanning →"
            />
          </Panel>
        )}
      </main>
    </div>
  );
}

function Stepper({ step }: { step: Step }) {
  const labels = ["Allergies", "Skin", "Hair", "Review"];
  return (
    <ol className="mb-8 flex items-center gap-2 text-xs font-mono uppercase tracking-widest">
      {labels.map((l, i) => (
        <li key={l} className="flex items-center gap-2">
          <span
            className={`grid h-6 w-6 place-items-center rounded-md border ${
              i <= step
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border text-muted-foreground"
            }`}
          >
            {i + 1}
          </span>
          <span className={i === step ? "text-foreground" : "text-muted-foreground"}>
            {l}
          </span>
          {i < labels.length - 1 && (
            <span className="mx-2 h-px w-6 bg-border" />
          )}
        </li>
      ))}
    </ol>
  );
}

function Panel({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="glass-panel p-8">
      <h1 className="font-display text-3xl font-semibold tracking-tight">
        {title}
      </h1>
      {subtitle && (
        <p className="mt-2 text-sm text-muted-foreground">{subtitle}</p>
      )}
      <div className="mt-8">{children}</div>
    </section>
  );
}

function Row({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex gap-6 border-b border-border/60 pb-4">
      <dt className="w-24 font-mono text-xs uppercase tracking-widest text-muted-foreground">
        {label}
      </dt>
      <dd className="flex-1">{children}</dd>
    </div>
  );
}

function Footer({
  onBack,
  onNext,
  nextLabel,
}: {
  onBack: (() => void) | null;
  onNext: () => void;
  nextLabel: string;
}) {
  return (
    <div className="mt-10 flex items-center justify-between">
      {onBack ? (
        <button
          onClick={onBack}
          className="rounded-full px-5 py-2 text-sm text-muted-foreground transition hover:text-foreground"
        >
          ← Back
        </button>
      ) : (
        <span />
      )}
      <button
        onClick={onNext}
        className="rounded-full bg-primary px-6 py-3 font-medium text-primary-foreground transition hover:opacity-90"
      >
        {nextLabel}
      </button>
    </div>
  );
}

function TypePicker({
  title,
  subtitle,
  options,
  currentValue,
  onSelect,
  onBack,
  onNext,
}: {
  title: string;
  subtitle: string;
  options: string[];
  currentValue: string | null;
  onSelect: (value: string) => void;
  onBack: () => void;
  onNext: () => void;
}) {
  const [mode, setMode] = useState<"pick" | "other">("pick");
  const [custom, setCustom] = useState("");

  const isOtherSelected = currentValue !== null && !options.includes(currentValue);
  const effectiveValue = isOtherSelected ? currentValue : null;

  const selectOption = (opt: string) => {
    setMode("pick");
    setCustom("");
    onSelect(opt);
  };

  const selectOther = () => {
    setMode("other");
    if (custom.trim()) onSelect(custom.trim());
  };

  const updateCustom = (v: string) => {
    setCustom(v);
    if (mode === "other") onSelect(v.trim());
  };

  return (
    <Panel title={title} subtitle={subtitle}>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {options.map((opt) => (
          <button
            key={opt}
            onClick={() => selectOption(opt)}
            className={`rounded-xl border px-4 py-4 text-left font-medium transition ${
              currentValue === opt
                ? "border-primary bg-primary/10 text-foreground"
                : "border-border bg-secondary/40 text-muted-foreground hover:border-primary/60 hover:text-foreground"
            }`}
          >
            {opt}
          </button>
        ))}
        <button
          onClick={selectOther}
          className={`rounded-xl border px-4 py-4 text-left font-medium transition ${
            isOtherSelected || mode === "other"
              ? "border-primary bg-primary/10 text-foreground"
              : "border-border bg-secondary/40 text-muted-foreground hover:border-primary/60 hover:text-foreground"
          }`}
        >
          Other
        </button>
      </div>

      {(mode === "other" || isOtherSelected) && (
        <div className="mt-4">
          <input
            value={mode === "other" ? custom : effectiveValue ?? ""}
            onChange={(e) => updateCustom(e.target.value)}
            placeholder="Type your skin / hair type"
            className="w-full rounded-xl border border-input bg-secondary/40 px-4 py-3 outline-none placeholder:text-muted-foreground focus:border-primary"
          />
        </div>
      )}

      <Footer onBack={onBack} onNext={onNext} nextLabel="Continue" />
    </Panel>
  );
}
