import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppNav } from "@/components/AppNav";
import { clearProfile, loadProfile, type Profile } from "@/lib/profile-store";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Your profile · PurePicks" },
      {
        name: "description",
        content:
          "View and manage your allergy, skin, and hair profile stored locally on this device.",
      },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setProfile(loadProfile());
    setMounted(true);
  }, []);

  return (
    <div className="min-h-screen">
      <AppNav />
      <main className="mx-auto max-w-3xl px-6 py-12">
        <h1 className="font-display text-4xl font-semibold tracking-tight md:text-5xl">
          Your profile
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Stored locally on this device. Nothing is sent until you scan a product.
        </p>

        {mounted && !profile && (
          <div className="mt-10 glass-panel p-8 text-center">
            <p className="text-muted-foreground">No profile yet.</p>
            <Link
              to="/onboarding"
              className="mt-5 inline-block rounded-full bg-primary px-5 py-2.5 font-medium text-primary-foreground transition hover:opacity-90"
            >
              Set one up →
            </Link>
          </div>
        )}

        {profile && (
          <div className="mt-10 space-y-4">
            <Card label="Allergies & sensitivities">
              {profile.allergies.length ? (
                <div className="flex flex-wrap gap-2">
                  {profile.allergies.map((a) => (
                    <span key={a} className="chip">
                      {a}
                    </span>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">None reported</p>
              )}
            </Card>

            <Card label="Skin">
              <div className="font-display text-2xl font-semibold">
                {profile.skinType ?? "—"}
              </div>
              {profile.skinNotes && (
                <p className="mt-2 text-sm text-muted-foreground">
                  {profile.skinNotes}
                </p>
              )}
            </Card>

            <Card label="Hair">
              <div className="font-display text-2xl font-semibold">
                {profile.hairType ?? "—"}
              </div>
              {profile.hairNotes && (
                <p className="mt-2 text-sm text-muted-foreground">
                  {profile.hairNotes}
                </p>
              )}
            </Card>

            <div className="flex flex-wrap gap-3 pt-4">
              <Link
                to="/onboarding"
                className="rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition hover:opacity-90"
              >
                Update profile
              </Link>
              <button
                onClick={() => {
                  if (confirm("Delete your profile from this device?")) {
                    clearProfile();
                    setProfile(null);
                  }
                }}
                className="rounded-full border border-border bg-secondary/60 px-5 py-2.5 text-sm text-muted-foreground transition hover:border-destructive hover:text-destructive"
              >
                Clear profile
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

function Card({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <section className="glass-panel p-6">
      <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
        {label}
      </div>
      <div className="mt-3">{children}</div>
    </section>
  );
}
