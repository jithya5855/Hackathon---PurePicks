import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppNav } from "@/components/AppNav";
import {
  loadHistory,
  toggleFavorite,
  deleteScan,
  clearHistory,
  type ScanHistoryEntry,
} from "@/lib/history-store";
import type { ProductVerdict } from "@/lib/ai.functions";

export const Route = createFileRoute("/history")({
  head: () => ({
    meta: [
      { title: "Scan history · PurePicks" },
      {
        name: "description",
        content: "Revisit past product scans, favorites, and results.",
      },
    ],
  }),
  component: HistoryPage,
});

type Filter = "all" | "favorites";

const verdictMeta: Record<
  ProductVerdict,
  { label: string; dot: string }
> = {
  safe: { label: "Safe", dot: "bg-success" },
  caution: { label: "Caution", dot: "bg-warning" },
  avoid: { label: "Avoid", dot: "bg-destructive" },
};

function HistoryPage() {
  const [entries, setEntries] = useState<ScanHistoryEntry[]>([]);
  const [filter, setFilter] = useState<Filter>("all");
  const [selected, setSelected] = useState<ScanHistoryEntry | null>(null);

  useEffect(() => {
    setEntries(loadHistory());
  }, []);

  const refresh = () => setEntries(loadHistory());

  const filtered =
    filter === "favorites" ? entries.filter((e) => e.favorite) : entries;

  return (
    <div className="min-h-screen">
      <AppNav />
      <main className="mx-auto max-w-5xl px-6 py-12">
        <header className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <span className="chip">
              <span className="h-1.5 w-1.5 rounded-full bg-accent" />
              History
            </span>
            <h1 className="mt-3 font-display text-4xl font-semibold tracking-tight md:text-5xl">
              Your scans
            </h1>
          </div>
          {entries.length > 0 && (
            <button
              onClick={() => {
                if (confirm("Clear all scan history?")) {
                  clearHistory();
                  refresh();
                }
              }}
              className="rounded-full border border-destructive/40 px-4 py-1.5 text-sm text-destructive transition hover:bg-destructive/10"
            >
              Clear history
            </button>
          )}
        </header>

        <div className="mb-6 flex items-center gap-2">
          {(["all", "favorites"] as Filter[]).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`rounded-full border px-4 py-1.5 text-sm capitalize transition ${
                filter === f
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-secondary/40 text-muted-foreground hover:text-foreground"
              }`}
            >
              {f === "all" ? `All (${entries.length})` : `Favorites (${entries.filter((e) => e.favorite).length})`}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div className="glass-panel flex flex-col items-center justify-center gap-4 py-20 text-center">
            <div className="grid h-16 w-16 place-items-center rounded-full border border-border bg-background text-3xl text-muted-foreground">
              ◎
            </div>
            <p className="text-muted-foreground">
              {filter === "favorites"
                ? "No favorites yet. Heart a scan to save it here."
                : "No scans yet. Head to the scanner to analyze your first product."}
            </p>
            <Link
              to="/scan"
              className="rounded-full bg-primary px-6 py-2 text-sm font-medium text-primary-foreground transition hover:opacity-90"
            >
              Start scanning
            </Link>
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((entry) => (
              <ScanCard
                key={entry.id}
                entry={entry}
                onToggle={() => {
                  toggleFavorite(entry.id);
                  refresh();
                }}
                onDelete={() => {
                  deleteScan(entry.id);
                  refresh();
                }}
                onRevisit={() => setSelected(entry)}
              />
            ))}
          </div>
        )}
      </main>

      {selected && (
        <DetailModal
          entry={selected}
          onClose={() => setSelected(null)}
          onToggle={() => {
            toggleFavorite(selected.id);
            refresh();
            setSelected({ ...selected, favorite: !selected.favorite });
          }}
        />
      )}
    </div>
  );
}

function ScanCard({
  entry,
  onToggle,
  onDelete,
  onRevisit,
}: {
  entry: ScanHistoryEntry;
  onToggle: () => void;
  onDelete: () => void;
  onRevisit: () => void;
}) {
  const v = verdictMeta[entry.result.verdict];
  const date = new Date(entry.scannedAt).toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
  const time = new Date(entry.scannedAt).toLocaleTimeString(undefined, {
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <div className="glass-panel group flex flex-col overflow-hidden transition hover:border-primary/40">
      <button
        onClick={onRevisit}
        className="relative aspect-[4/3] w-full overflow-hidden bg-secondary/40"
      >
        {entry.imageDataUrl ? (
          <img
            src={entry.imageDataUrl}
            alt={entry.result.productName}
            className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full items-center justify-center text-3xl text-muted-foreground">
            ◎
          </div>
        )}
        <div className="absolute left-3 top-3 flex items-center gap-1.5 rounded-full bg-background/80 px-2.5 py-1 text-[10px] font-medium backdrop-blur-sm">
          <span className={`h-1.5 w-1.5 rounded-full ${v.dot}`} />
          {v.label}
        </div>
      </button>

      <div className="flex flex-1 flex-col p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <div className="truncate text-sm font-semibold">
              {entry.result.productName}
            </div>
            <div className="mt-0.5 text-xs text-muted-foreground">
              {date} · {time} · <span className="capitalize">{entry.category}</span>
            </div>
          </div>
          <button
            onClick={onToggle}
            className="shrink-0 rounded-full p-1.5 text-muted-foreground transition hover:bg-secondary hover:text-accent"
            aria-label={entry.favorite ? "Unfavorite" : "Favorite"}
          >
            {entry.favorite ? "★" : "☆"}
          </button>
        </div>

        <p className="mt-2 line-clamp-2 text-xs text-muted-foreground">
          {entry.result.summary}
        </p>

        <div className="mt-auto flex items-center justify-between pt-3">
          <button
            onClick={onRevisit}
            className="text-xs font-medium text-accent transition hover:underline"
          >
            View details →
          </button>
          <button
            onClick={onDelete}
            className="rounded-full p-1.5 text-xs text-muted-foreground transition hover:bg-destructive/10 hover:text-destructive"
            aria-label="Delete"
          >
            🗑
          </button>
        </div>
      </div>
    </div>
  );
}

function DetailModal({
  entry,
  onClose,
  onToggle,
}: {
  entry: ScanHistoryEntry;
  onClose: () => void;
  onToggle: () => void;
}) {
  const v = verdictMeta[entry.result.verdict];

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center bg-background/80 p-4 backdrop-blur-sm"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="glass-panel mt-12 max-h-[85vh] w-full max-w-xl overflow-y-auto p-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className={`h-2 w-2 rounded-full ${v.dot}`} />
              <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
                {v.label}
              </span>
            </div>
            <h2 className="mt-1 font-display text-2xl font-semibold tracking-tight">
              {entry.result.productName}
            </h2>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={onToggle}
              className="rounded-full p-2 text-lg text-muted-foreground transition hover:bg-secondary hover:text-accent"
              aria-label={entry.favorite ? "Unfavorite" : "Favorite"}
            >
              {entry.favorite ? "★" : "☆"}
            </button>
            <button
              onClick={onClose}
              className="rounded-full p-2 text-muted-foreground transition hover:bg-secondary hover:text-foreground"
              aria-label="Close"
            >
              ✕
            </button>
          </div>
        </div>

        {entry.imageDataUrl && (
          <img
            src={entry.imageDataUrl}
            alt={entry.result.productName}
            className="mt-4 w-full rounded-xl border border-border object-cover"
          />
        )}

        <p className="mt-4 text-sm">{entry.result.summary}</p>

        {entry.result.allergyMatches.length > 0 && (
          <Section title="Allergy matches">
            <div className="flex flex-wrap gap-2">
              {entry.result.allergyMatches.map((a) => (
                <span
                  key={a}
                  className="chip border-destructive/50 text-destructive"
                >
                  ⚠ {a}
                </span>
              ))}
            </div>
          </Section>
        )}

        {entry.result.flaggedIngredients.length > 0 && (
          <Section title="Flagged ingredients">
            <ul className="space-y-2">
              {entry.result.flaggedIngredients.map((f) => (
                <li
                  key={f.name}
                  className="rounded-lg border border-border bg-background/40 p-3 text-sm"
                >
                  <div className="font-medium">{f.name}</div>
                  <div className="mt-1 text-muted-foreground">{f.reason}</div>
                </li>
              ))}
            </ul>
          </Section>
        )}

        {entry.result.alternatives.length > 0 && (
          <Section title="Better alternatives">
            <ul className="space-y-2">
              {entry.result.alternatives.map((a) => (
                <li
                  key={a.name}
                  className="rounded-lg border border-border bg-background/40 p-3 text-sm"
                >
                  <div className="font-medium text-accent">{a.name}</div>
                  <div className="mt-1 text-muted-foreground">{a.why}</div>
                </li>
              ))}
            </ul>
          </Section>
        )}

        {entry.result.lifestyleTips.length > 0 && (
          <Section title="Lifestyle tips">
            <ul className="space-y-1.5 text-sm text-muted-foreground">
              {entry.result.lifestyleTips.map((t) => (
                <li key={t} className="flex gap-2">
                  <span className="text-accent">→</span>
                  <span>{t}</span>
                </li>
              ))}
            </ul>
          </Section>
        )}

        <div className="mt-6 text-center text-xs text-muted-foreground">
          Informational guidance only — not medical advice.
        </div>
      </div>
    </div>
  );
}

function Section({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="mt-5">
      <div className="mb-2 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
        {title}
      </div>
      {children}
    </div>
  );
}
